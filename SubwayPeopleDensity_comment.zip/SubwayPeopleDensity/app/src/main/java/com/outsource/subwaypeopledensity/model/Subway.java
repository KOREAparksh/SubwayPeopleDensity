package com.outsource.subwaypeopledensity.model;

public class Subway {

    int box_1_people,box_2_people,box_3_people,box_4_people,box_5_people,box_6_people,box_7_people,box_8_people;

    public Subway(int box_1_people, int box_2_people, int box_3_people, int box_4_people, int box_5_people, int box_6_people, int box_7_people, int box_8_people) {
        this.box_1_people = box_1_people;
        this.box_2_people = box_2_people;
        this.box_3_people = box_3_people;
        this.box_4_people = box_4_people;
        this.box_5_people = box_5_people;
        this.box_6_people = box_6_people;
        this.box_7_people = box_7_people;
        this.box_8_people = box_8_people;
    }

    public int getBox_1_people() {
        return box_1_people;
    }

    public int getBox_2_people() {
        return box_2_people;
    }

    public int getBox_3_people() {
        return box_3_people;
    }

    public int getBox_4_people() {
        return box_4_people;
    }

    public int getBox_5_people() {
        return box_5_people;
    }

    public int getBox_6_people() {
        return box_6_people;
    }

    public int getBox_7_people() {
        return box_7_people;
    }

    public int getBox_8_people() {
        return box_8_people;
    }
}
