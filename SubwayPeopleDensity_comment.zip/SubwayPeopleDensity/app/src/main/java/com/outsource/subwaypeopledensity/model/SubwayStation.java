package com.outsource.subwaypeopledensity.model;

import java.util.ArrayList;

public class SubwayStation {

    public static final int TOTAL_STATION_COUNT = 22;

    public static final String[] daejeonStations = {
            "반석",
            "지족",
            "노은",
            "월드컵경기장",
            "현충원",
            "구암",
            "유성온천",
            "갑천",
            "월평",
            "갈마",
            "정부청사",
            "시청",
            "탄방",
            "용문",
            "오룡",
            "서대전네거리",
            "중구청",
            "중앙로",
            "대전역",
            "대동",
            "신흥",
            "판암"
    };

}
